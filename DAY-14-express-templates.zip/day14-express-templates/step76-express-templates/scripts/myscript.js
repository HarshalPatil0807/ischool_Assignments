document.addEventListener("DOMContentLoaded", function(){
    document.getElementsByTagName("h1")[0].style = "border : 1px dashed crimson; text-align : center; padding : 10px"
})