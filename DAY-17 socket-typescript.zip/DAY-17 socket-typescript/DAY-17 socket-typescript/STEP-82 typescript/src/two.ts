// let message: string = "hello there us ";
alert(message);
