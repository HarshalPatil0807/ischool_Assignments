//mongodb assignment.

const express = require("express");
const mongoose = require("mongoose");
const app = express();


//middleware
//---------------------------------------------
app.use(express.static(__dirname+"/public"));
app.use(express.json());



app.listen(5050,function(error){
    if(error){
        console.log("Error ",error)
    }else{
        console.log("Server is now live on localhost : 5050")
    }
});